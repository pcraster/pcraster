#ifndef INCLUDED_CALC_SIMDMATHTEST
#define INCLUDED_CALC_SIMDMATHTEST



#ifndef INCLUDED_STDDEFX
#include "stddefx.h"
#define INCLUDED_STDDEFX
#endif

#ifndef INCLUDED_TESTCASE
#include "TestCase.h"
#define INCLUDED_TESTCASE
#endif

// Library headers.

// PCRaster library headers.

// Module headers.



class Test;

namespace calc {
  // SIMDMath declarations.
}



namespace calc {



//! This class implements the unit tests for the SIMDMath class.
class SIMDMathTest: public TestCase
{

private:

public:

                   SIMDMathTest           (std::string const& name);

  void             setUp               ();

  void             tearDown            ();

  void             testLoop            ();
  void             testMVPropagation   ();
  void             testDomainErrors    ();

  static Test*     suite               ();

};

} // namespace calc

#endif
