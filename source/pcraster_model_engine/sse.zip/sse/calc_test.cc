#include "stddefx.h"


#include "TestRunner.h"

#ifndef INCLUDED_CALC_SIMDMATHTEST
#include "calc_simdmathtest.h"
#define INCLUDED_CALC_SIMDMATHTEST
#endif


namespace calc {
 int testLib(int argc, char **argv)
 {

  TestRunner runner;

  runner.addTest("calc::SIMDMathTest", SIMDMathTest::suite());

  return runner.run(argc, argv);
 }
}
